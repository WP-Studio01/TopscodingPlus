console.log(window,'Topscoding Plus插件成功运行');
//window.alert('Topscoding Plus插件成功运行');
var imgs=document.getElementsByTagName('img');
for(var it of imgs)
{
	if(it.height>1000)
	{
		//it.style.display='none';
		it.outerHTML='超大图片已被屏蔽';
	}
}