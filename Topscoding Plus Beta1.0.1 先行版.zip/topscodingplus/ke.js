console.log(window,'Topscoding Plus插件成功运行');
//window.alert('Topscoding Plus插件成功运行');
var imgs=document.getElementsByTagName('img');
for(var it of imgs)
{
	if(it.height>100)
	{
		it.style.display='none';
	}
}